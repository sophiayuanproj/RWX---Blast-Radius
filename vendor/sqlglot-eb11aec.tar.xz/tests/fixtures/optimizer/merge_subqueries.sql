# title: Simple
SELECT a, b FROM (SELECT a, b FROM x);
SELECT x.a AS a, x.b AS b FROM x AS x;

# title: Wrap addition in a multiplication
SELECT c * 2 AS d FROM (SELECT a + b AS c FROM x);
SELECT (x.a + x.b) * 2 AS d FROM x AS x;

# title: Wrap addition in an addition
# note: The "simplify" rule will unwrap this
SELECT c + d AS e FROM (SELECT a + b AS c, a AS d FROM x);
SELECT (x.a + x.b) + x.a AS e FROM x AS x;

# title: Wrap multiplication in an addition
# note: The "simplify" rule will unwrap this
WITH cte AS (SELECT a * b AS c, a AS d FROM x) SELECT c + d AS e FROM cte;
SELECT (x.a * x.b) + x.a AS e FROM x AS x;

# title: Don't wrap function
SELECT 2 * foo AS bar FROM (SELECT CAST(b AS DOUBLE) AS foo FROM x);
SELECT 2 * CAST(x.b AS DOUBLE) AS bar FROM x AS x;

# title: Wrap comparison in IN
SELECT c IN (FALSE) AS d FROM (SELECT a > 1 AS c FROM x);
SELECT (x.a > 1) IN (FALSE) AS d FROM x AS x;

# title: Wrap IS NULL in BETWEEN
SELECT c BETWEEN FALSE AND TRUE AS d FROM (SELECT a IS NULL AS c FROM x);
SELECT (x.a IS NULL) BETWEEN FALSE AND TRUE AS d FROM x AS x;

# title: Wrap comparison used as a BETWEEN bound
SELECT FALSE BETWEEN FALSE AND c AS d FROM (SELECT a > 1 AS c FROM x);
SELECT FALSE BETWEEN FALSE AND (x.a > 1) AS d FROM x AS x;

# title: Wrap AND in IN
SELECT c IN (FALSE) AS d FROM (SELECT a > 1 AND b > 1 AS c FROM x);
SELECT (x.a > 1 AND x.b > 1) IN (FALSE) AS d FROM x AS x;

# title: Wrap equality in IN
SELECT c IN (FALSE) AS d FROM (SELECT a = 1 AS c FROM x);
SELECT (x.a = 1) IN (FALSE) AS d FROM x AS x;

# title: Don't wrap equality in AND
SELECT c AND b = 1 AS d FROM (SELECT a = 1 AS c, b FROM x);
SELECT x.a = 1 AND x.b = 1 AS d FROM x AS x;

# title: Wrap OR in AND
SELECT c AND b > 0 AS d FROM (SELECT a > 1 OR b > 1 AS c, b FROM x);
SELECT (x.a > 1 OR x.b > 1) AND x.b > 0 AS d FROM x AS x;

# title: Don't wrap an IN list element
SELECT TRUE IN (c, FALSE) AS d FROM (SELECT a > 1 AS c FROM x);
SELECT TRUE IN (x.a > 1, FALSE) AS d FROM x AS x;

# title: Don't wrap the list operand of DuckDB's IN
# dialect: duckdb
# execute_min_python: 3.11
SELECT 1 IN f AS d FROM (SELECT [a, b][1:1] AS f FROM x);
SELECT 1 IN [x.a, x.b][1:1] AS d FROM x AS x;

# title: Don't wrap a wrapped expression
SELECT foo * 2 AS bar FROM (SELECT (1 + 2 + 3) AS foo FROM x);
SELECT (1 + 2 + 3) * 2 AS bar FROM x AS x;

# title: Inner table alias is merged
SELECT a, b FROM (SELECT a, b FROM x AS q) AS r;
SELECT q.a AS a, q.b AS b FROM x AS q;

# title: Double nesting
SELECT a, b FROM (SELECT a, b FROM (SELECT a, b FROM x));
SELECT x.a AS a, x.b AS b FROM x AS x;

# title: WHERE clause is merged
SELECT a, SUM(b) AS b FROM (SELECT a, b FROM x WHERE a > 1) GROUP BY a;
SELECT x.a AS a, SUM(x.b) AS b FROM x AS x WHERE x.a > 1 GROUP BY x.a;

# title: Outer query has join
SELECT a, c FROM (SELECT a, b FROM x WHERE a > 1) AS x JOIN y ON x.b = y.b;
SELECT x.a AS a, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b WHERE x.a > 1;

# title: Leave tables isolated
# leave_tables_isolated: true
SELECT a, c FROM (SELECT a, b FROM x WHERE a > 1) AS x JOIN y ON x.b = y.b;
SELECT x.a AS a, y.c AS c FROM (SELECT x.a AS a, x.b AS b FROM x AS x WHERE x.a > 1) AS x JOIN y AS y ON x.b = y.b;

# title: Join on derived table
SELECT a, c FROM x JOIN (SELECT b, c FROM y) AS y ON x.b = y.b;
SELECT x.a AS a, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

# title: Inner query has a join
SELECT a, c FROM (SELECT a, c FROM x JOIN y ON x.b = y.b);
SELECT x.a AS a, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

# title: Inner query has conflicting name in outer query
SELECT a, c FROM (SELECT q.a, q.b FROM x AS q) AS x JOIN y AS q ON x.b = q.b;
SELECT q_2.a AS a, q.c AS c FROM x AS q_2 JOIN y AS q ON q_2.b = q.b;

# title: Inner query has conflicting name in ANTI join source
SELECT d2.c1 FROM (SELECT a AS c1 FROM x AS x) AS d2 ANTI JOIN x AS x ON c1 >= 0;
SELECT x_2.a AS c1 FROM x AS x_2 ANTI JOIN x AS x ON x_2.a >= 0;

# title: Inner query has conflicting name in joined source
SELECT x.a, q.c FROM (SELECT a, x.b FROM x JOIN y AS q ON x.b = q.b) AS x JOIN y AS q ON x.b = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x JOIN y AS q_2 ON x.b = q_2.b JOIN y AS q ON x.b = q.b;

# title: Inner query has multiple conflicting names
SELECT x.a, q.c, r.c FROM (SELECT q.a, r.b FROM x AS q JOIN y AS r ON q.b = r.b) AS x JOIN y AS q ON x.b = q.b JOIN y AS r ON x.b = r.b ORDER BY x.a, q.c, r.c;
SELECT q_2.a AS a, q.c AS c, r.c AS c FROM x AS q_2 JOIN y AS r_2 ON q_2.b = r_2.b JOIN y AS q ON r_2.b = q.b JOIN y AS r ON r_2.b = r.b ORDER BY q_2.a, q.c, r.c;

# title: Inner queries have conflicting names with each other
SELECT r.b FROM (SELECT b FROM x AS x) AS q JOIN (SELECT b FROM x) AS r ON q.b = r.b;
SELECT x_2.b AS b FROM x AS x JOIN x AS x_2 ON x.b = x_2.b;

# title: WHERE clause in joined derived table is merged to ON clause
SELECT x.a, y.c FROM x JOIN (SELECT b, c FROM y WHERE c > 1) AS y ON x.b = y.b ORDER BY x.a;
SELECT x.a AS a, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b AND y.c > 1 ORDER BY x.a;

# title: Comma JOIN in outer query
SELECT x.a, y.c FROM (SELECT a FROM x) AS x, (SELECT c FROM y) AS y;
SELECT x.a AS a, y.c AS c FROM x AS x, y AS y;

# title: Comma JOIN in inner query
SELECT x.a, x.c FROM (SELECT x.a, z.c FROM x, y AS z) AS x;
SELECT x.a AS a, z.c AS c FROM x AS x, y AS z;

# title: (Regression) Column in ORDER BY
SELECT * FROM (SELECT * FROM (SELECT * FROM x)) ORDER BY a LIMIT 1;
SELECT x.a AS a, x.b AS b FROM x AS x ORDER BY x.a LIMIT 1;

# title: CTE
WITH x AS (SELECT a, b FROM main.x) SELECT a, b FROM x;
SELECT x.a AS a, x.b AS b FROM main.x AS x;

# title: CTE with outer table alias
WITH y AS (SELECT a, b FROM x) SELECT a, b FROM y AS z;
SELECT x.a AS a, x.b AS b FROM x AS x;

# title: Nested CTE
WITH x2 AS (SELECT a FROM main.x), x3 AS (SELECT a FROM x2) SELECT a FROM x3;
SELECT x.a AS a FROM main.x AS x;

# title: CTE WHERE clause is merged
WITH x AS (SELECT a, b FROM main.x WHERE a > 1) SELECT a, SUM(b) AS b FROM x GROUP BY a;
SELECT x.a AS a, SUM(x.b) AS b FROM main.x AS x WHERE x.a > 1 GROUP BY x.a;

# title: CTE Outer query has join
WITH x2 AS (SELECT a, b FROM x WHERE a > 1) SELECT a, c FROM x2 AS x JOIN y ON x.b = y.b;
SELECT x.a AS a, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b WHERE x.a > 1;

# title: CTE with inner table alias
WITH y AS (SELECT a, b FROM x AS q) SELECT a, b FROM y AS z;
SELECT q.a AS a, q.b AS b FROM x AS q;

# title: Nested CTE
SELECT * FROM (WITH x AS (SELECT a, b FROM main.x) SELECT a, b FROM x);
SELECT x.a AS a, x.b AS b FROM main.x AS x;

# title: Inner select is an expression
SELECT a FROM (SELECT a FROM (SELECT COALESCE(a) AS a FROM x LEFT JOIN y ON x.a = y.b) AS x) AS x;
SELECT COALESCE(x.a) AS a FROM x AS x LEFT JOIN y AS y ON x.a = y.b;

# title: CTE select is an expression
WITH x2 AS (SELECT COALESCE(a) AS a FROM x LEFT JOIN y ON x.a = y.b) SELECT a FROM (SELECT a FROM x2 AS x) AS x;
SELECT COALESCE(x.a) AS a FROM x AS x LEFT JOIN y AS y ON x.a = y.b;

# title: Full outer join
SELECT x.b AS b, y.b AS b2 FROM (SELECT x.b AS b FROM x AS x WHERE x.b = 1) AS x FULL OUTER JOIN (SELECT y.b AS b FROM y AS y WHERE y.b = 2) AS y ON x.b = y.b;
SELECT x.b AS b, y.b AS b2 FROM (SELECT x.b AS b FROM x AS x WHERE x.b = 1) AS x FULL OUTER JOIN (SELECT y.b AS b FROM y AS y WHERE y.b = 2) AS y ON x.b = y.b;

# title: Full outer join, no predicates
SELECT x.b AS b, y.b AS b2 FROM (SELECT x.b AS b FROM x AS x) AS x FULL OUTER JOIN (SELECT y.b AS b FROM y AS y) AS y ON x.b = y.b;
SELECT x.b AS b, y.b AS b2 FROM x AS x FULL OUTER JOIN y AS y ON x.b = y.b;

# title: Left join
SELECT x.b AS b, y.b AS b2 FROM (SELECT x.b AS b FROM x AS x WHERE x.b = 1) AS x LEFT JOIN (SELECT y.b AS b FROM y AS y WHERE y.b = 2) AS y ON x.b = y.b;
SELECT x.b AS b, y.b AS b2 FROM x AS x LEFT JOIN (SELECT y.b AS b FROM y AS y WHERE y.b = 2) AS y ON x.b = y.b WHERE x.b = 1;

# title: Left join, no predicates
SELECT x.b AS b, y.b AS b2 FROM (SELECT x.b AS b FROM x AS x) AS x LEFT JOIN (SELECT y.b AS b FROM y AS y) AS y ON x.b = y.b;
SELECT x.b AS b, y.b AS b2 FROM x AS x LEFT JOIN y AS y ON x.b = y.b;

# title: Right join
SELECT x.b AS b, y.b AS b2 FROM (SELECT x.b AS b FROM x AS x WHERE x.b = 1) AS x RIGHT JOIN (SELECT y.b AS b FROM y AS y WHERE y.b = 2) AS y ON x.b = y.b;
SELECT x.b AS b, y.b AS b2 FROM (SELECT x.b AS b FROM x AS x WHERE x.b = 1) AS x RIGHT JOIN (SELECT y.b AS b FROM y AS y WHERE y.b = 2) AS y ON x.b = y.b;

# title: Right join, no predicates
SELECT x.b AS b, y.b AS b2 FROM (SELECT x.b AS b FROM x AS x) AS x RIGHT JOIN (SELECT y.b AS b FROM y AS y) AS y ON x.b = y.b;
SELECT x.b AS b, y.b AS b2 FROM x AS x RIGHT JOIN y AS y ON x.b = y.b;

# title: Left join with a constant projection
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, 1 AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (SELECT y.b AS b, 1 AS c FROM y AS y) AS q ON x.a = q.b;

# title: Left join with COALESCE
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, COALESCE(y.c, 0) AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (SELECT y.b AS b, COALESCE(y.c, 0) AS c FROM y AS y) AS q ON x.a = q.b;

# title: Left join with CASE
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, CASE WHEN y.c IS NULL THEN 0 ELSE y.c END AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (SELECT y.b AS b, CASE WHEN y.c IS NULL THEN 0 ELSE y.c END AS c FROM y AS y) AS q ON x.a = q.b;

# title: Left join with IS NULL
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, y.c IS NULL AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (SELECT y.b AS b, y.c IS NULL AS c FROM y AS y) AS q ON x.a = q.b;

# title: Left join with a null-safe comparison
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, y.c IS NOT DISTINCT FROM NULL AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (SELECT y.b AS b, y.c IS NOT DISTINCT FROM NULL AS c FROM y AS y) AS q ON x.a = q.b;

# title: Left join with a null-safe inequality
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, y.c IS DISTINCT FROM NULL AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (SELECT y.b AS b, y.c IS DISTINCT FROM NULL AS c FROM y AS y) AS q ON x.a = q.b;

# title: Left join with OR TRUE
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, y.c = 1 OR TRUE AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (SELECT y.b AS b, y.c = 1 OR TRUE AS c FROM y AS y) AS q ON x.a = q.b;

# title: Left join with CONCAT
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, CONCAT(y.c, 'x') AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (SELECT y.b AS b, CONCAT(y.c, 'x') AS c FROM y AS y) AS q ON x.a = q.b;

# title: Left join with GREATEST
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, GREATEST(y.c, 1) AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (SELECT y.b AS b, GREATEST(y.c, 1) AS c FROM y AS y) AS q ON x.a = q.b;

# title: Left join with a binary function
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, POWER(y.c, 0) AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (SELECT y.b AS b, POWER(y.c, 0) AS c FROM y AS y) AS q ON x.a = q.b;

# title: Left join with NULLIF
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, NULLIF(1, y.c) AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (SELECT y.b AS b, NULLIF(1, y.c) AS c FROM y AS y) AS q ON x.a = q.b;

# title: Left join with dialect-dependent concatenation
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, CAST(y.c AS TEXT) || 'x' AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (SELECT y.b AS b, CAST(y.c AS TEXT) || 'x' AS c FROM y AS y) AS q ON x.a = q.b;

# title: Left join with a nested non-null-propagating expression
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, COALESCE(y.c, 0) + 1 AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (SELECT y.b AS b, COALESCE(y.c, 0) + 1 AS c FROM y AS y) AS q ON x.a = q.b;

# title: Right join with a constant on the null-supplying side
SELECT q.a, y.c FROM (SELECT x.b, 1 AS a FROM x) AS q RIGHT JOIN y ON q.b = y.b;
SELECT q.a AS a, y.c AS c FROM (SELECT x.b AS b, 1 AS a FROM x AS x) AS q RIGHT JOIN y AS y ON q.b = y.b;

# title: Full join with non-null-propagating projections on both sides
SELECT p.a, q.c FROM (SELECT x.b, 1 AS a FROM x) AS p FULL JOIN (SELECT y.b, COALESCE(y.c, 0) AS c FROM y) AS q ON p.b = q.b;
SELECT p.a AS a, q.c AS c FROM (SELECT x.b AS b, 1 AS a FROM x AS x) AS p FULL JOIN (SELECT y.b AS b, COALESCE(y.c, 0) AS c FROM y AS y) AS q ON p.b = q.b;

# title: Joined subquery on the null-supplying side of a later right join
SELECT q.c FROM x JOIN (SELECT y.b, 1 AS c FROM y) AS q ON x.a = q.b RIGHT JOIN y AS r ON x.a = r.b;
SELECT q.c AS c FROM x AS x JOIN (SELECT y.b AS b, 1 AS c FROM y AS y) AS q ON x.a = q.b RIGHT JOIN y AS r ON x.a = r.b;

# title: Joined subquery on the null-supplying side of a later full join
SELECT q.c FROM x JOIN (SELECT y.b, 1 AS c FROM y) AS q ON x.a = q.b FULL JOIN y AS r ON x.a = r.b;
SELECT q.c AS c FROM x AS x JOIN (SELECT y.b AS b, 1 AS c FROM y AS y) AS q ON x.a = q.b FULL JOIN y AS r ON x.a = r.b;

# title: Left join with a constant referenced only in WHERE
SELECT x.a FROM x LEFT JOIN (SELECT y.b, 1 AS c FROM y) AS q ON x.a = q.b WHERE q.c IS NULL;
SELECT x.a AS a FROM x AS x LEFT JOIN (SELECT y.b AS b, 1 AS c FROM y AS y) AS q ON x.a = q.b WHERE q.c IS NULL;

# title: Left join with a constant in a CTE
WITH cte AS (SELECT y.b, 1 AS c FROM y) SELECT x.a, q.c FROM x LEFT JOIN cte AS q ON x.a = q.b;
WITH cte AS (SELECT y.b AS b, 1 AS c FROM y AS y) SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN cte AS q ON x.a = q.b;

# title: Constant projection inside a parenthesized left join
WITH cte AS (SELECT y.b, 1 AS c FROM y) SELECT x.a, q.c FROM (x LEFT JOIN cte AS q ON x.a = q.b);
WITH cte AS (SELECT y.b AS b, 1 AS c FROM y AS y) SELECT x.a AS a, q.c AS c FROM (x AS x LEFT JOIN cte AS q ON x.a = q.b);

# title: Constant projection inside the null-supplying side of an enclosing join
WITH cte AS (SELECT y.b, 1 AS c FROM y) SELECT x.a, q.c FROM x LEFT JOIN (y AS r JOIN cte AS q ON r.b = q.b) ON x.a = r.b;
WITH cte AS (SELECT y.b AS b, 1 AS c FROM y AS y) SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (y AS r JOIN cte AS q ON r.b = q.b) ON x.a = r.b;

# title: Constant projection in the first source of a parenthesized right join
WITH cte AS (SELECT y.b, 1 AS c FROM y) SELECT q.c FROM (cte AS q RIGHT JOIN x ON x.a = q.b);
WITH cte AS (SELECT y.b AS b, 1 AS c FROM y AS y) SELECT q.c AS c FROM (cte AS q RIGHT JOIN x AS x ON x.a = q.b);

# title: First source of a parenthesized join is null-supplied by a later right join
WITH cte AS (SELECT y.b, 1 AS c FROM y) SELECT q.c FROM (cte AS q JOIN x ON x.a = q.b) RIGHT JOIN y AS r ON x.a = r.b;
WITH cte AS (SELECT y.b AS b, 1 AS c FROM y AS y) SELECT q.c AS c FROM (cte AS q JOIN x AS x ON x.a = q.b) RIGHT JOIN y AS r ON x.a = r.b;

# title: Left join with an unused constant projection can merge
SELECT x.a, q.b FROM x LEFT JOIN (SELECT y.b, 1 AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, y.b AS b FROM x AS x LEFT JOIN y AS y ON x.a = y.b;

# title: Left join with null-propagating arithmetic can merge
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, y.c + 1 AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, y.c + 1 AS c FROM x AS x LEFT JOIN y AS y ON x.a = y.b;

# title: Left join with null-propagating bitwise arithmetic can merge
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, y.c & 1 AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, y.c & 1 AS c FROM x AS x LEFT JOIN y AS y ON x.a = y.b;

# title: Left join with nested null-propagating expressions can merge
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, CAST(-(y.c + 1) AS BIGINT) AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, CAST(-(y.c + 1) AS BIGINT) AS c FROM x AS x LEFT JOIN y AS y ON x.a = y.b;

# title: Left join with null-propagating comparisons can merge
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, NOT y.c = 1 AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, NOT y.c = 1 AS c FROM x AS x LEFT JOIN y AS y ON x.a = y.b;

# title: Left join with a struct field can merge
SELECT x.a, q.c FROM x LEFT JOIN (SELECT t.b, t.s.a AS c FROM (VALUES (2, STRUCT(3 AS a)), (3, NULL)) AS t(b, s)) AS q ON x.a = q.b;
SELECT x.a AS a, t.s.a AS c FROM x AS x LEFT JOIN (VALUES (2, STRUCT(3 AS a)), (3, NULL)) AS t(b, s) ON x.a = t.b;

# title: Left join with a nested struct field can merge
SELECT x.a, q.c FROM x LEFT JOIN (SELECT t.b, t.s.n.a AS c FROM (VALUES (2, STRUCT(STRUCT(3 AS a) AS n)), (3, NULL)) AS t(b, s)) AS q ON x.a = q.b;
SELECT x.a AS a, t.s.n.a AS c FROM x AS x LEFT JOIN (VALUES (2, STRUCT(STRUCT(3 AS a) AS n)), (3, NULL)) AS t(b, s) ON x.a = t.b;

# title: Left join with a field of a constructed struct stays isolated
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, (STRUCT(1 AS a, y.c AS b)).a AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, q.c AS c FROM x AS x LEFT JOIN (SELECT y.b AS b, (STRUCT(1 AS a, y.c AS b)).a AS c FROM y AS y) AS q ON x.a = q.b;

# title: Left join with arithmetic propagating NULL from the right operand can merge
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, 1 - y.c AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, 1 - y.c AS c FROM x AS x LEFT JOIN y AS y ON x.a = y.b;

# title: Left join with a NULL projection can merge
SELECT x.a, q.c FROM x LEFT JOIN (SELECT y.b, NULL AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, NULL AS c FROM x AS x LEFT JOIN y AS y ON x.a = y.b;

# title: Constant on the preserved side of a left join can merge
SELECT q.a, y.c FROM (SELECT x.b, 1 AS a FROM x) AS q LEFT JOIN y ON q.b = y.b;
SELECT 1 AS a, y.c AS c FROM x AS x LEFT JOIN y AS y ON x.b = y.b;

# title: Constant on the preserved side of a right join can merge
SELECT x.a, q.c FROM x RIGHT JOIN (SELECT y.b, 1 AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, 1 AS c FROM x AS x RIGHT JOIN y AS y ON x.a = y.b;

# title: A preceding right join does not prevent merging a later constant projection
SELECT q.c FROM x RIGHT JOIN y AS r ON x.a = r.b JOIN (SELECT y.b, 1 AS c FROM y) AS q ON r.b = q.b;
SELECT 1 AS c FROM x AS x RIGHT JOIN y AS r ON x.a = r.b JOIN y AS y ON r.b = y.b;

# title: Inner join with COALESCE can merge
SELECT x.a, q.c FROM x JOIN (SELECT y.b, COALESCE(y.c, 0) AS c FROM y) AS q ON x.a = q.b;
SELECT x.a AS a, COALESCE(y.c, 0) AS c FROM x AS x JOIN y AS y ON x.a = y.b;

# title: Inner join
SELECT x.b AS b, y.b AS b2 FROM (SELECT x.b AS b FROM x AS x WHERE x.b = 1) AS x INNER JOIN (SELECT y.b AS b FROM y AS y WHERE y.b = 2) AS y ON x.b = y.b;
SELECT x.b AS b, y.b AS b2 FROM x AS x INNER JOIN y AS y ON x.b = y.b AND y.b = 2 WHERE x.b = 1;

# title: Inner join, no predicates
SELECT x.b AS b, y.b AS b2 FROM (SELECT x.b AS b FROM x AS x) AS x INNER JOIN (SELECT y.b AS b FROM y AS y) AS y ON x.b = y.b;
SELECT x.b AS b, y.b AS b2 FROM x AS x INNER JOIN y AS y ON x.b = y.b;

# title: Cross join
SELECT x.b AS b, y.b AS b2 FROM (SELECT x.b AS b FROM x AS x WHERE x.b = 1) AS x CROSS JOIN (SELECT y.b AS b FROM y AS y WHERE y.b = 2) AS y;
SELECT x.b AS b, y.b AS b2 FROM x AS x JOIN y AS y ON y.b = 2 WHERE x.b = 1;

# title: Cross join, no predicates
SELECT x.b AS b, y.b AS b2 FROM (SELECT x.b AS b FROM x AS x) AS x CROSS JOIN (SELECT y.b AS b FROM y AS y) AS y;
SELECT x.b AS b, y.b AS b2 FROM x AS x CROSS JOIN y AS y;

# title: Broadcast hint
# dialect: spark
WITH m AS (SELECT x.a, x.b FROM x), n AS (SELECT y.b, y.c FROM y), joined as (SELECT /*+ BROADCAST(k) */ m.a, k.c FROM m JOIN n AS k ON m.b = k.b) SELECT joined.a, joined.c FROM joined;
SELECT /*+ BROADCAST(y) */ x.a AS a, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

# title: Broadcast hint multiple tables
# dialect: spark
WITH m AS (SELECT x.a, x.b FROM x), n AS (SELECT y.b, y.c FROM y), joined as (SELECT /*+ BROADCAST(m, n) */ m.a, n.c FROM m JOIN n ON m.b = n.b) SELECT joined.a, joined.c FROM joined;
SELECT /*+ BROADCAST(x, y) */ x.a AS a, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

# title: Multiple Table Hints
# dialect: spark
WITH m AS (SELECT x.a, x.b FROM x), n AS (SELECT y.b, y.c FROM y), joined as (SELECT /*+ BROADCAST(m), MERGE(m, n) */ m.a, n.c FROM m JOIN n ON m.b = n.b) SELECT joined.a, joined.c FROM joined;
SELECT /*+ BROADCAST(x), MERGE(x, y) */ x.a AS a, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

# title: Mix Table and Column Hints
# dialect: spark
WITH m AS (SELECT x.a, x.b FROM x), n AS (SELECT y.b, y.c FROM y), joined as (SELECT /*+ BROADCAST(m), MERGE(m, n) */ m.a, n.c FROM m JOIN n ON m.b = n.b) SELECT /*+ COALESCE(3) */ joined.a, joined.c FROM joined;
SELECT /*+ COALESCE(3), BROADCAST(x), MERGE(x, y) */ x.a AS a, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

# title: Hint Subquery
# dialect: spark
SELECT
    subquery.a,
    subquery.c
FROM (
    SELECT /*+ BROADCAST(m), MERGE(m, n) */ m.a, n.c FROM (SELECT x.a, x.b FROM x) AS m JOIN (SELECT y.b, y.c FROM y) AS n ON m.b = n.b
) AS subquery;
SELECT /*+ BROADCAST(x), MERGE(x, y) */ x.a AS a, y.c AS c FROM x AS x JOIN y AS y ON x.b = y.b;

# title: Subquery Test
# dialect: spark
SELECT /*+ BROADCAST(x) */
  x.a,
  x.c
FROM (
  SELECT
    x.a,
    x.c
  FROM (
    SELECT
      x.a,
      COUNT(1) AS c
    FROM x
    GROUP BY x.a
  ) AS x
) AS x;
SELECT /*+ BROADCAST(x) */ x.a AS a, x.c AS c FROM (SELECT x.a AS a, COUNT(1) AS c FROM x AS x GROUP BY x.a) AS x;

# title: Test preventing merge of window expressions where clause
with t1 as (
  SELECT
    x.a,
    x.b,
    ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) as row_num
  FROM
    x
  ORDER BY x.a, x.b, row_num
)
SELECT
  t1.a,
  t1.b
FROM
  t1
WHERE
  row_num = 1;
WITH t1 AS (SELECT x.a AS a, x.b AS b, ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) AS row_num FROM x AS x ORDER BY x.a, x.b, row_num) SELECT t1.a AS a, t1.b AS b FROM t1 AS t1 WHERE t1.row_num = 1;

# title: Test preventing merge of window expressions join clause
with t1 as (
  SELECT
    x.a,
    x.b,
    ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) as row_num
  FROM
    x
)
SELECT
  t1.a,
  t1.b
FROM t1 JOIN y ON t1.a = y.c AND t1.row_num = 1;
WITH t1 AS (SELECT x.a AS a, x.b AS b, ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) AS row_num FROM x AS x) SELECT t1.a AS a, t1.b AS b FROM t1 AS t1 JOIN y AS y ON t1.a = y.c AND t1.row_num = 1;

# title: Test preventing merge of window expressions agg function
with t1 as (
  SELECT
    x.a,
    x.b,
    ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) as row_num
  FROM
    x
)
SELECT
  SUM(t1.row_num) as total_rows
FROM
  t1;
WITH t1 AS (SELECT x.a AS a, x.b AS b, ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) AS row_num FROM x AS x) SELECT SUM(t1.row_num) AS total_rows FROM t1 AS t1;

# title: Test prevent merging of window if in group by
with t1 as (
  SELECT
    x.a,
    x.b,
    ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) as row_num
  FROM
    x
)
SELECT
  t1.row_num AS row_num,
  SUM(t1.a) AS total
FROM
  t1
GROUP BY t1.row_num
ORDER BY t1.row_num;
WITH t1 AS (SELECT x.a AS a, x.b AS b, ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) AS row_num FROM x AS x) SELECT t1.row_num AS row_num, SUM(t1.a) AS total FROM t1 AS t1 GROUP BY t1.row_num ORDER BY row_num;

# title: Test prevent merging of window if in order by
with t1 as (
  SELECT
    x.a,
    x.b,
    ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) as row_num
  FROM
    x
)
SELECT
  t1.row_num AS row_num,
  t1.a AS a
FROM
  t1
ORDER BY t1.row_num, t1.a;
WITH t1 AS (SELECT x.a AS a, x.b AS b, ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) AS row_num FROM x AS x) SELECT t1.row_num AS row_num, t1.a AS a FROM t1 AS t1 ORDER BY t1.row_num, t1.a;

# title: Test preventing merging of window nested under complex projection if in order by
WITH t1 AS (
  SELECT
    x.a,
    x.b,
    ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) - 1 AS row_num
  FROM
    x
)
SELECT
  t1.row_num AS row_num,
  t1.a AS a
FROM
  t1
ORDER BY t1.row_num, t1.a;
WITH t1 AS (SELECT x.a AS a, x.b AS b, ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) - 1 AS row_num FROM x AS x) SELECT t1.row_num AS row_num, t1.a AS a FROM t1 AS t1 ORDER BY t1.row_num, t1.a;

# title: Test allow merging of window function
with t1 as (
  SELECT
    x.a,
    x.b,
    ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) as row_num
  FROM
    x
  ORDER BY x.a, x.b, row_num
)
SELECT
  t1.a,
  t1.b,
  t1.row_num
FROM
  t1;
SELECT x.a AS a, x.b AS b, ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) AS row_num FROM x AS x ORDER BY x.a, x.b, row_num;

# title: Keep ORDER BY
# execute: false
WITH t AS (SELECT t1.x AS x, t1.y AS y, t2.a AS a, t2.b AS b FROM t1 AS t1(x, y) CROSS JOIN t2 AS t2(a, b) ORDER BY t2.a) SELECT t.x AS x, t.y AS y, t.a AS a, t.b AS b FROM t AS t;
SELECT t1.x AS x, t1.y AS y, t2.a AS a, t2.b AS b FROM t1 AS t1(x, y) CROSS JOIN t2 AS t2(a, b) ORDER BY t2.a;

# title: Do not merge window functions, inner table is aliased in outer query
with t1 as (
  SELECT
    ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) as row_num
  FROM
    x
)
SELECT
  t2.row_num
FROM
  t1 AS t2
WHERE
  t2.row_num = 2;
WITH t1 AS (SELECT ROW_NUMBER() OVER (PARTITION BY x.a ORDER BY x.a) AS row_num FROM x AS x) SELECT t2.row_num AS row_num FROM t1 AS t2 WHERE t2.row_num = 2;

# title: Values Test
# dialect: spark
WITH t1 AS (
  SELECT
    a1.cola
  FROM
    VALUES (1) AS a1(cola)
), t2 AS (
  SELECT
    a2.cola
  FROM
    VALUES (1) AS a2(cola)
)
SELECT /*+ BROADCAST(t2) */
  t1.cola,
  t2.cola,
FROM
  t1
  JOIN
  t2
  ON
    t1.cola = t2.cola;
SELECT /*+ BROADCAST(a2) */ a1.cola AS cola, a2.cola AS cola FROM VALUES (1) AS a1(cola) JOIN VALUES (1) AS a2(cola) ON a1.cola = a2.cola;

# title: Nested subquery selects from same table as another subquery
WITH i AS (
  SELECT
    x.a AS a
  FROM x AS x
), j AS (
  SELECT
    x.a,
    x.b
  FROM x AS x
), k AS (
  SELECT
    j.a,
    j.b
  FROM j AS j
)
SELECT
  i.a,
  k.b
FROM i AS i
LEFT JOIN k AS k
ON  i.a = k.a;
SELECT x.a AS a, x_2.b AS b FROM x AS x LEFT JOIN x AS x_2 ON x.a = x_2.a;

# title: Outer select joins on inner select join
WITH i AS (
  SELECT
    x.a AS a
  FROM y AS y
  JOIN x AS x
    ON y.b = x.b
)
SELECT
  x.a AS a
FROM x AS x
LEFT JOIN i AS i
  ON x.a = i.a;
WITH i AS (SELECT x.a AS a FROM y AS y JOIN x AS x ON y.b = x.b) SELECT x.a AS a FROM x AS x LEFT JOIN i AS i ON x.a = i.a;

# title: Outer scope selects from wrapped table with a join (unknown schema)
# execute: false
WITH _q_0 AS (SELECT t1.c AS c FROM t1 AS t1) SELECT * FROM (_q_0 AS _q_0 CROSS JOIN t2 AS t2);
WITH _q_0 AS (SELECT t1.c AS c FROM t1 AS t1) SELECT * FROM (_q_0 AS _q_0 CROSS JOIN t2 AS t2);

# title: Outer scope selects single column from wrapped table with a join
WITH _q_0 AS (
  SELECT
    x.a AS a
  FROM x AS x
), y_2 AS (
  SELECT
    y.b AS b
  FROM y AS y
)
SELECT
  y.b AS b
FROM (
  _q_0 AS _q_0
    JOIN y_2 AS y
      ON _q_0.a = y.b
);
SELECT y.b AS b FROM (x AS x JOIN y AS y ON x.a = y.b);

# title: merge cte into subquery with overlapping alias
WITH q AS (
  SELECT
    y.b AS a
  FROM y AS y
)
SELECT
  q.a AS a
FROM x AS q
WHERE
  q.a IN (
    SELECT
      q.a AS a
    FROM q AS q
  );
SELECT q.a AS a FROM x AS q WHERE q.a IN (SELECT y.b AS a FROM y AS y);

# title: dont merge when inner query has ORDER BY and outer query is UNION
WITH q AS (
  SELECT
    x.a AS a
  FROM x
  ORDER BY x.a
)
SELECT
  q.a AS a
FROM q
UNION ALL
SELECT
  1 AS a;
WITH q AS (SELECT x.a AS a FROM x AS x ORDER BY x.a) SELECT q.a AS a FROM q AS q UNION ALL SELECT 1 AS a;

# title: Consecutive inner - outer conflicting names
WITH tbl AS (select 1 as id)
SELECT
  id
FROM (
  SELECT OTBL.id
  FROM (
    SELECT OTBL.id
    FROM (
      SELECT OTBL.id
      FROM tbl AS OTBL
      LEFT OUTER JOIN tbl AS ITBL ON OTBL.id = ITBL.id
    ) AS OTBL
    LEFT OUTER JOIN tbl AS ITBL ON OTBL.id = ITBL.id
  ) AS OTBL
  LEFT OUTER JOIN tbl AS ITBL ON OTBL.id = ITBL.id
) AS ITBL;
WITH tbl AS (SELECT 1 AS id) SELECT OTBL.id AS id FROM tbl AS OTBL LEFT OUTER JOIN tbl AS ITBL_2 ON OTBL.id = ITBL_2.id LEFT OUTER JOIN tbl AS ITBL_3 ON OTBL.id = ITBL_3.id LEFT OUTER JOIN tbl AS ITBL ON OTBL.id = ITBL.id;

# title: Inner query contains subquery with an alias that conflicts with outer query
WITH i AS (
  SELECT
    a
  FROM (
    SELECT 1 a
  ) AS conflict
), j AS (
  SELECT 1 AS a
)
SELECT
  i.a,
  conflict.a
FROM i
LEFT JOIN j AS conflict
  ON i.a = conflict.a;
WITH j AS (SELECT 1 AS a) SELECT conflict_2.a AS a, conflict.a AS a FROM (SELECT 1 AS a) AS conflict_2 LEFT JOIN j AS conflict ON conflict_2.a = conflict.a;

# title: column name is not lost
with cte as (
    select x.a * x.b as mult from x
)
select cte.mult from cte;
SELECT x.a * x.b AS mult FROM x AS x;

# title: avoid merging subquery with JOIN
WITH t0 AS (
  SELECT
    5 AS id
), t1 AS (
  SELECT
    1 AS id,
    'US' AS cid
), t2 AS (
  SELECT
    1 AS id,
    'US' AS cid
)
SELECT
  t0.id,
  t3.cid AS cid
FROM t0
INNER JOIN (
  SELECT
    t1.id,
    t2.cid
  FROM t1
  RIGHT JOIN t2
    ON t1.cid = t2.cid
) AS t3
  ON t0.id = t3.id;
WITH t0 AS (SELECT 5 AS id), t1 AS (SELECT 1 AS id, 'US' AS cid), t2 AS (SELECT 1 AS id, 'US' AS cid) SELECT t0.id AS id, t3.cid AS cid FROM t0 AS t0 INNER JOIN (SELECT t1.id AS id, t2.cid AS cid FROM t1 AS t1 RIGHT JOIN t2 AS t2 ON t1.cid = t2.cid) AS t3 ON t0.id = t3.id;

# title: Numeric-literal GROUP BY becomes a positional ordinal (matching qualify) while ORDER BY keeps the alias
WITH t1 AS (SELECT 1 AS col) SELECT a, SUM(b) AS b FROM (SELECT 6 AS a, col AS b FROM t1) AS t GROUP BY a ORDER BY a;
WITH t1 AS (SELECT 1 AS col) SELECT 6 AS a, SUM(t1.col) AS b FROM t1 AS t1 GROUP BY 1 ORDER BY a;

# title: Literal GROUP BY reference not projected in the outer SELECT blocks the merge
SELECT MAX(x.b) AS lit FROM x CROSS JOIN (SELECT 6 AS lit FROM z) AS t GROUP BY t.lit;
SELECT MAX(x.b) AS lit FROM x AS x CROSS JOIN (SELECT 6 AS lit FROM z AS z) AS t GROUP BY t.lit;

# title: Literal projection whose alias collides with a base-table column merges via ordinal
SELECT s.a, SUM(s.b) AS b FROM (SELECT 6 AS a, b FROM x) AS s GROUP BY s.a ORDER BY s.a;
SELECT 6 AS a, SUM(x.b) AS b FROM x AS x GROUP BY 1 ORDER BY a;

# title: Literal projection colliding with an unmergeable-CTE column merges via ordinal
WITH c AS (SELECT DISTINCT a, b FROM x) SELECT s.a, SUM(s.b) AS b FROM (SELECT 6 AS a, b FROM c) AS s GROUP BY s.a ORDER BY s.a;
WITH c AS (SELECT DISTINCT x.a AS a, x.b AS b FROM x AS x) SELECT 6 AS a, SUM(c.b) AS b FROM c AS c GROUP BY 1 ORDER BY a;

# title: Literal projection colliding with an outer joined table column merges via ordinal
WITH c AS (SELECT DISTINCT x.b AS b FROM x) SELECT s.a, SUM(s.b) AS b FROM (SELECT 6 AS a, b FROM c) AS s CROSS JOIN x GROUP BY s.a ORDER BY s.a;
WITH c AS (SELECT DISTINCT x.b AS b FROM x AS x) SELECT 6 AS a, SUM(c.b) AS b FROM c AS c CROSS JOIN x AS x GROUP BY 1 ORDER BY a;

# title: Literal projection merges via ordinal even when a joined table's schema is unknown
# execute: false
SELECT s.a, SUM(s.b) AS b FROM (SELECT 6 AS a, y.b AS b FROM y) AS s CROSS JOIN unknown_tbl GROUP BY s.a ORDER BY s.a;
SELECT 6 AS a, SUM(y.b) AS b FROM y AS y CROSS JOIN unknown_tbl AS unknown_tbl GROUP BY 1 ORDER BY a;

# title: Literal projection referenced in ROLLUP blocks the merge (ordinals are not portable there)
SELECT s.a, SUM(s.b) AS b FROM (SELECT 6 AS a, b FROM x) AS s GROUP BY ROLLUP(s.a) ORDER BY s.a;
SELECT s.a AS a, SUM(s.b) AS b FROM (SELECT 6 AS a, x.b AS b FROM x AS x) AS s GROUP BY ROLLUP (s.a) ORDER BY a;

# title: Literal projection referenced inside a GROUPING SETS tuple blocks the merge
SELECT s.a, s.b, COUNT(*) AS c FROM (SELECT 6 AS a, b FROM x) AS s GROUP BY GROUPING SETS ((s.a, s.b)) ORDER BY s.b;
SELECT s.a AS a, s.b AS b, COUNT(*) AS c FROM (SELECT 6 AS a, x.b AS b FROM x AS x) AS s GROUP BY GROUPING SETS ((s.a, s.b)) ORDER BY b;

# title: Literal projection referenced inside a tuple GROUP BY item blocks the merge
SELECT s.a, s.b, COUNT(*) AS c FROM (SELECT 6 AS a, b FROM x) AS s GROUP BY (s.a, s.b) ORDER BY s.b;
SELECT s.a AS a, s.b AS b, COUNT(*) AS c FROM (SELECT 6 AS a, x.b AS b FROM x AS x) AS s GROUP BY (s.a, s.b) ORDER BY b;

# title: Paren-wrapped literal GROUP BY reference merges via the projection ordinal
SELECT s.a, SUM(s.b) AS b FROM (SELECT 6 AS a, b FROM x) AS s GROUP BY (s.a) ORDER BY s.a;
SELECT 6 AS a, SUM(x.b) AS b FROM x AS x GROUP BY 1 ORDER BY a;

# title: Paren-wrapped literal inside a tuple GROUP BY item blocks the merge
SELECT s.a, s.b, COUNT(*) AS c FROM (SELECT 6 AS a, b FROM x) AS s GROUP BY ((s.a), s.b) ORDER BY s.b;
SELECT s.a AS a, s.b AS b, COUNT(*) AS c FROM (SELECT 6 AS a, x.b AS b FROM x AS x) AS s GROUP BY ((s.a), s.b) ORDER BY b;

# title: Literal inside a paren-wrapped tuple GROUP BY item blocks the merge
SELECT s.a, s.b, COUNT(*) AS c FROM (SELECT 6 AS a, b FROM x) AS s GROUP BY ((s.a, s.b)) ORDER BY s.b;
SELECT s.a AS a, s.b AS b, COUNT(*) AS c FROM (SELECT 6 AS a, x.b AS b FROM x AS x) AS s GROUP BY ((s.a, s.b)) ORDER BY b;

# title: Paren-wrapped literal ORDER BY reference blocks the merge
SELECT s.a FROM (SELECT 6 AS a, b FROM x) AS s ORDER BY (s.a);
SELECT s.a AS a FROM (SELECT 6 AS a, x.b AS b FROM x AS x) AS s ORDER BY (s.a);

# title: Window function is not merged when the outer query filters its input rows
SELECT s.w FROM (SELECT a, ROW_NUMBER() OVER (ORDER BY a) AS w FROM x) AS s WHERE s.a > 5;
SELECT s.w AS w FROM (SELECT x.a AS a, ROW_NUMBER() OVER (ORDER BY x.a) AS w FROM x AS x) AS s WHERE s.a > 5;

# title: Window function is not merged when the outer query joins, changing its input rows
SELECT s.w FROM (SELECT b, ROW_NUMBER() OVER (ORDER BY b) AS w FROM x) AS s JOIN y ON s.b = y.b;
SELECT s.w AS w FROM (SELECT x.b AS b, ROW_NUMBER() OVER (ORDER BY x.b) AS w FROM x AS x) AS s JOIN y AS y ON s.b = y.b;

# title: Numeric-literal projection referenced in ORDER BY is not merged into a positional ORDER BY
# execute: false
SELECT s.b FROM (SELECT 6 AS a, b FROM x) AS s ORDER BY s.a;
SELECT s.b AS b FROM (SELECT 6 AS a, x.b AS b FROM x AS x) AS s ORDER BY s.a;

# title: Numeric-literal ORDER BY key is not merged when a join is present
# execute: false
WITH c AS (SELECT DISTINCT b FROM x) SELECT s.b FROM (SELECT 6 AS a, b FROM c) AS s CROSS JOIN x ORDER BY s.a;
WITH c AS (SELECT DISTINCT x.b AS b FROM x AS x) SELECT s.b AS b FROM (SELECT 6 AS a, c.b AS b FROM c AS c) AS s CROSS JOIN x AS x ORDER BY s.a;

# title: A single-use CTE merge must not leave a stale scope for the later derived-table pass
WITH c AS (SELECT a FROM (SELECT a, b FROM x) AS q WHERE q.b > 1) SELECT c.a FROM c JOIN y ON c.a = y.b;
SELECT x.a AS a FROM x AS x JOIN y AS y ON x.a = y.b WHERE x.b > 1;

# title: Window function nested inside a merged CTE is still blocked from merging into a join
WITH c AS (SELECT rn FROM (SELECT ROW_NUMBER() OVER (ORDER BY a) AS rn FROM x) AS q) SELECT c.rn FROM c JOIN y ON c.rn = y.b;
SELECT q.rn AS rn FROM (SELECT ROW_NUMBER() OVER (ORDER BY x.a) AS rn FROM x AS x) AS q JOIN y AS y ON q.rn = y.b;

# title: A CTE merge that reintroduces a name colliding with the outer join still renames correctly
WITH c AS (SELECT q.a FROM (SELECT x.a FROM x AS x) AS q) SELECT c.a FROM c JOIN x ON c.a = x.a;
SELECT x_2.a AS a FROM x AS x_2 JOIN x AS x ON x_2.a = x.a;

# title: Each reference that needs wrapping gets a single pair of parentheses
WITH q AS (SELECT a + b AS c FROM x) SELECT q.c * 1 AS c1, q.c * 2 AS c2, q.c * 3 AS c3 FROM q;
SELECT (x.a + x.b) * 1 AS c1, (x.a + x.b) * 2 AS c2, (x.a + x.b) * 3 AS c3 FROM x AS x;

# title: Derived-table merge preserves a correlated JOIN ON reference after source renaming
SELECT d.b FROM (SELECT z.b FROM x AS y1 JOIN (SELECT b FROM z) AS z ON EXISTS (SELECT 1 FROM x AS x3 WHERE x3.a < z.b)) AS d CROSS JOIN z AS z;
SELECT z_2.b AS b FROM x AS y1 JOIN z AS z_2 ON EXISTS(SELECT 1 AS "1" FROM x AS x3 WHERE x3.a < z_2.b) CROSS JOIN z AS z;

# title: Derived-table merge preserves a correlated JOIN ON reference with a distinct outer alias
SELECT d.b FROM (SELECT z.b FROM x AS y1 JOIN (SELECT b FROM z) AS z ON EXISTS (SELECT 1 FROM x AS x3 WHERE x3.a < z.b)) AS d CROSS JOIN z AS outer_z;
SELECT z.b AS b FROM x AS y1 JOIN z AS z ON EXISTS(SELECT 1 AS "1" FROM x AS x3 WHERE x3.a < z.b) CROSS JOIN z AS outer_z;

# title: Derived-table merge renames correlated references through nested JOIN ON subqueries
SELECT d.b FROM (SELECT z.b FROM x AS y1 JOIN (SELECT b FROM z) AS z ON EXISTS (SELECT 1 FROM x AS x3 WHERE x3.a < z.b AND EXISTS (SELECT 1 FROM x AS x4 WHERE x4.a < z.b))) AS d CROSS JOIN z AS z;
SELECT z_2.b AS b FROM x AS y1 JOIN z AS z_2 ON EXISTS(SELECT 1 AS "1" FROM x AS x3 WHERE x3.a < z_2.b AND EXISTS(SELECT 1 AS "1" FROM x AS x4 WHERE x4.a < z_2.b)) CROSS JOIN z AS z;

# title: Derived-table merge renames correlated references in a JOIN ON UNION ALL subquery
SELECT d.b FROM (SELECT z.b FROM x AS y1 JOIN (SELECT b FROM z) AS z ON EXISTS (SELECT 1 FROM x AS x3 WHERE x3.a < z.b UNION ALL SELECT 1 FROM x AS x4 WHERE x4.a < z.b)) AS d CROSS JOIN z AS z;
SELECT z_2.b AS b FROM x AS y1 JOIN z AS z_2 ON EXISTS(SELECT 1 AS "1" FROM x AS x3 WHERE x3.a < z_2.b UNION ALL SELECT 1 AS "1" FROM x AS x4 WHERE x4.a < z_2.b) CROSS JOIN z AS z;

# title: Derived-table merge renames correlated references without changing a locally shadowed alias
SELECT d.b FROM (SELECT z.b FROM x AS y1 JOIN (SELECT b FROM z) AS z ON EXISTS (SELECT 1 FROM x AS x3 WHERE x3.a < z.b AND EXISTS (SELECT 1 FROM x AS z WHERE z.a > z.b))) AS d CROSS JOIN z AS z;
SELECT z_2.b AS b FROM x AS y1 JOIN z AS z_2 ON EXISTS(SELECT 1 AS "1" FROM x AS x3 WHERE x3.a < z_2.b AND EXISTS(SELECT 1 AS "1" FROM x AS z WHERE z.a > z.b)) CROSS JOIN z AS z;

# title: Derived-table merge leaves an uncorrelated locally shadowed alias unchanged
SELECT d.b FROM (SELECT z.b FROM x AS y1 JOIN (SELECT b FROM z) AS z ON EXISTS (SELECT 1 FROM x AS z WHERE z.a > z.b)) AS d CROSS JOIN z AS z;
SELECT z_2.b AS b FROM x AS y1 JOIN z AS z_2 ON EXISTS(SELECT 1 AS "1" FROM x AS z WHERE z.a > z.b) CROSS JOIN z AS z;

# title: CTE merge preserves a correlated JOIN ON reference after source renaming
WITH source_z AS (SELECT b FROM z), d AS (SELECT z.b FROM x AS y1 JOIN source_z AS z ON EXISTS (SELECT 1 FROM x AS x3 WHERE x3.a < z.b)) SELECT d.b FROM d CROSS JOIN z AS z;
SELECT z_2.b AS b FROM x AS y1 JOIN z AS z_2 ON EXISTS(SELECT 1 AS "1" FROM x AS x3 WHERE x3.a < z_2.b) CROSS JOIN z AS z;

# title: CTE merge preserves a correlated JOIN ON reference with a distinct outer alias
WITH source_z AS (SELECT b FROM z), d AS (SELECT z.b FROM x AS y1 JOIN source_z AS z ON EXISTS (SELECT 1 FROM x AS x3 WHERE x3.a < z.b)) SELECT d.b FROM d CROSS JOIN z AS outer_z;
SELECT z.b AS b FROM x AS y1 JOIN z AS z ON EXISTS(SELECT 1 AS "1" FROM x AS x3 WHERE x3.a < z.b) CROSS JOIN z AS outer_z;

# title: CTE merge renames correlated references through nested JOIN ON subqueries
WITH source_z AS (SELECT b FROM z), d AS (SELECT z.b FROM x AS y1 JOIN source_z AS z ON EXISTS (SELECT 1 FROM x AS x3 WHERE x3.a < z.b AND EXISTS (SELECT 1 FROM x AS x4 WHERE x4.a < z.b))) SELECT d.b FROM d CROSS JOIN z AS z;
SELECT z_2.b AS b FROM x AS y1 JOIN z AS z_2 ON EXISTS(SELECT 1 AS "1" FROM x AS x3 WHERE x3.a < z_2.b AND EXISTS(SELECT 1 AS "1" FROM x AS x4 WHERE x4.a < z_2.b)) CROSS JOIN z AS z;

# title: CTE merge renames correlated references in a JOIN ON UNION ALL subquery
WITH source_z AS (SELECT b FROM z), d AS (SELECT z.b FROM x AS y1 JOIN source_z AS z ON EXISTS (SELECT 1 FROM x AS x3 WHERE x3.a < z.b UNION ALL SELECT 1 FROM x AS x4 WHERE x4.a < z.b)) SELECT d.b FROM d CROSS JOIN z AS z;
SELECT z_2.b AS b FROM x AS y1 JOIN z AS z_2 ON EXISTS(SELECT 1 AS "1" FROM x AS x3 WHERE x3.a < z_2.b UNION ALL SELECT 1 AS "1" FROM x AS x4 WHERE x4.a < z_2.b) CROSS JOIN z AS z;

# title: CTE merge renames correlated references without changing a locally shadowed alias
WITH source_z AS (SELECT b FROM z), d AS (SELECT z.b FROM x AS y1 JOIN source_z AS z ON EXISTS (SELECT 1 FROM x AS x3 WHERE x3.a < z.b AND EXISTS (SELECT 1 FROM x AS z WHERE z.a > z.b))) SELECT d.b FROM d CROSS JOIN z AS z;
SELECT z_2.b AS b FROM x AS y1 JOIN z AS z_2 ON EXISTS(SELECT 1 AS "1" FROM x AS x3 WHERE x3.a < z_2.b AND EXISTS(SELECT 1 AS "1" FROM x AS z WHERE z.a > z.b)) CROSS JOIN z AS z;

# title: CTE merge leaves an uncorrelated locally shadowed alias unchanged
WITH source_z AS (SELECT b FROM z), d AS (SELECT z.b FROM x AS y1 JOIN source_z AS z ON EXISTS (SELECT 1 FROM x AS z WHERE z.a > z.b)) SELECT d.b FROM d CROSS JOIN z AS z;
SELECT z_2.b AS b FROM x AS y1 JOIN z AS z_2 ON EXISTS(SELECT 1 AS "1" FROM x AS z WHERE z.a > z.b) CROSS JOIN z AS z;

# title: A positional join in a separate CTE does not block ordinary derived-table merging
# dialect: duckdb
WITH p AS (SELECT x.a FROM x POSITIONAL JOIN y) SELECT s.a FROM (SELECT x.a FROM x) AS s CROSS JOIN p;
WITH p AS (SELECT x.a AS a FROM x AS x POSITIONAL JOIN y AS y) SELECT x.a AS a FROM x AS x CROSS JOIN p AS p;
